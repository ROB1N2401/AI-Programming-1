Student: Ivan Fomenko

General info:
	The field is generated each time project is launched. You can modify the scene runtime (controls are below), however you
cannot do that once you launched simulation. When Starchaser cannot find path to the current target, simulation will stop and 
a warning will be given in console, letting you know about that. After that you can modify the scene and press the button again 
to continue the simulation.

Symbols:
	-Starchaser is visualised by dynamically coloured circle;
	-Star is visualised by yellow star;
	-Trading Post is visualised by cyan romb;
	-Spaceship is visualised by green plus shape;
	-Unwalkable tiles are coloured grey, walkable - white;

Controls: 
	"Q" - Peposition Starchaser;
	"W" - Reposition Star;
	"E" - Reposition Trading Post;
	"R" - Reposition Spaceship;
	LMB - Change tile type;